# DukaBI Android Project (starter release)

DukaBI is an offline-first Kivy Android app starter with a dark navy interface and SQLite storage.

## Included in this starter
- Dashboard summary cards
- Record sales and expenses
- Product list and opening stock
- Daily and monthly reports
- Local SQLite database
- Android APK build configuration and GitHub Actions workflow

## Important accounting note
This starter subtracts a sold quantity from product stock when a matching product exists. If a sale is entered for a product not in the product list, the sale is still recorded but stock is not changed. Net profit is calculated as sales revenue minus recorded cost of goods sold minus expenses. Record costs accurately.

This is an early starter, not a fully audited accounting system. Test carefully with sample records before using it for real business.

## Run locally in Pydroid 3
1. Install Kivy in Pydroid 3 if your setup supports it.
2. Open `main.py` and run it.
3. The SQLite database is created inside Kivy's app data directory.

## Build a standalone APK using only your phone
Buildozer's Android toolchain requires Linux/macOS. This project includes a GitHub Actions workflow so you can use GitHub's hosted Linux runner from your phone's browser.

1. Sign in or create a GitHub account.
2. Create a new repository named `DukaBI-Android`.
3. Upload all files and folders in this project, including `.github/workflows/android.yml`.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and run **Build DukaBI Android APK** (or push a commit to `main`).
6. Wait for the workflow to finish. Open the completed run and download the `DukaBI-debug-apk` artifact.
7. Extract the downloaded ZIP, then install the APK on your Android phone. Android may ask you to allow installation from that browser or file manager.

## Build configuration
- App title: DukaBI
- Package ID: `org.dukabi.dukabi`
- Version: `0.1.0`
- Architecture: ARM64 and ARMv7
- App icon: `dukabi_icon.png`

## Before wider distribution
- Test on the target Android version and several screen sizes.
- Add a real backup/export workflow.
- Create and securely preserve a signing key for release builds.
- A debug APK is suitable for testing and direct trials, not the final public release.
