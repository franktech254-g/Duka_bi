[app]
title = DukaBI
package.name = dukabi
package.domain = org.dukabi
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,txt
version = 0.1.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
icon.filename = %(source.dir)s/dukabi_icon.png

[buildozer]
log_level = 2
warn_on_root = 1

[android]
# Minimum Android version suitable for many current devices.
android.minapi = 23
android.api = 35
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
android.allow_backup = True
android.private_storage = True
