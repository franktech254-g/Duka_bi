import os
import sqlite3
from datetime import date, datetime, timedelta

from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.spinner import Spinner
from kivy.uix.widget import Widget

NAVY = (0.025, 0.055, 0.11, 1)
PANEL = (0.045, 0.095, 0.17, 1)
PANEL2 = (0.065, 0.13, 0.22, 1)
GREEN = (0.0, 0.85, 0.42, 1)
BLUE = (0.0, 0.53, 1.0, 1)
ORANGE = (1.0, 0.58, 0.05, 1)
PURPLE = (0.48, 0.29, 1.0, 1)
CYAN = (0.0, 0.72, 0.78, 1)
WHITE = (0.94, 0.97, 1, 1)
MUTED = (0.65, 0.73, 0.84, 1)
RED = (1, 0.25, 0.28, 1)

DB_NAME = "dukabi.db"


def ksh(value):
    return "KSh {:,.2f}".format(float(value or 0))


def today():
    return date.today().isoformat()


def valid_date(value):
    return date.fromisoformat(value.strip()).isoformat()


class Card(BoxLayout):
    def __init__(self, bg=PANEL, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "vertical"
        self.padding = dp(12)
        self.spacing = dp(5)
        with self.canvas.before:
            Color(*bg)
            self._rect = RoundedRectangle(radius=[dp(14)])
        self.bind(pos=self._update_rect, size=self._update_rect)

    def _update_rect(self, *_):
        self._rect.pos = self.pos
        self._rect.size = self.size


class DukaBIApp(App):
    title = "DukaBI"

    def build(self):
        Window.clearcolor = NAVY
        self.db_path = os.path.join(self.user_data_dir, DB_NAME)
        self.init_db()
        self.root_box = BoxLayout(orientation="vertical", spacing=dp(0))
        self.header = BoxLayout(size_hint_y=None, height=dp(76), padding=[dp(16), dp(8)], spacing=dp(8))
        with self.header.canvas.before:
            Color(*PANEL)
            self.header_bg = RoundedRectangle(radius=[0])
        self.header.bind(pos=self._header_bg, size=self._header_bg)

        brand = BoxLayout(orientation="vertical", spacing=dp(0))
        brand.add_widget(Label(text="[b]Duka[/b][color=00D96B]BI[/color]", markup=True,
                               font_size="27sp", halign="left", valign="middle", color=WHITE))
        brand.add_widget(Label(text="Smart Supermarket Manager", font_size="11sp",
                               color=MUTED, halign="left", valign="top"))
        self.header.add_widget(brand)
        self.header.add_widget(self.make_button("☾", self.toggle_theme, bg=PANEL2, width=dp(48)))
        self.root_box.add_widget(self.header)

        self.body = BoxLayout(orientation="vertical")
        self.root_box.add_widget(self.body)

        nav = GridLayout(cols=5, size_hint_y=None, height=dp(62), spacing=dp(3), padding=[dp(5), dp(5)])
        for label, page in [("Home", "home"), ("Sales", "sales"), ("Expenses", "expenses"),
                            ("Reports", "reports"), ("Stock", "stock")]:
            nav.add_widget(self.make_button(label, lambda _b, p=page: self.show_page(p),
                                            bg=PANEL, font_size="11sp"))
        self.root_box.add_widget(nav)
        self.show_page("home")
        return self.root_box

    def _header_bg(self, *_):
        self.header_bg.pos = self.header.pos
        self.header_bg.size = self.header.size

    def init_db(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        with sqlite3.connect(self.db_path) as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS products(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                cost REAL NOT NULL DEFAULT 0 CHECK(cost >= 0),
                price REAL NOT NULL DEFAULT 0 CHECK(price >= 0),
                stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS sales(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_date TEXT NOT NULL,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK(quantity > 0),
                unit_price REAL NOT NULL CHECK(unit_price >= 0),
                unit_cost REAL NOT NULL DEFAULT 0 CHECK(unit_cost >= 0),
                payment_method TEXT NOT NULL DEFAULT 'Cash',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS expenses(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                expense_date TEXT NOT NULL,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                payment_method TEXT NOT NULL DEFAULT 'Cash',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date);
            CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
            """)

    def query(self, sql, args=(), one=False):
        with sqlite3.connect(self.db_path) as con:
            con.row_factory = sqlite3.Row
            cur = con.execute(sql, args)
            return cur.fetchone() if one else cur.fetchall()

    def execute(self, sql, args=()):
        with sqlite3.connect(self.db_path) as con:
            con.execute(sql, args)

    def make_label(self, text, size=14, color=WHITE, markup=False, height=None, halign="left"):
        lbl = Label(text=text, font_size=f"{size}sp", color=color, markup=markup,
                    halign=halign, valign="middle", size_hint_y=None if height else 1,
                    height=dp(height) if height else 0)
        lbl.bind(size=lambda inst, val: setattr(inst, "text_size", (val[0], None)))
        return lbl

    def make_button(self, text, callback, bg=GREEN, width=None, font_size="14sp"):
        btn = Button(text=text, size_hint_x=None if width else 1,
                     width=width or 0, size_hint_y=None, height=dp(44),
                     background_normal="", background_down="", background_color=bg,
                     color=WHITE, font_size=font_size, bold=True)
        btn.bind(on_release=callback)
        return btn

    def text_input(self, hint, text="", multiline=False, input_filter=None):
        return TextInput(text=text, hint_text=hint, multiline=multiline,
                         input_filter=input_filter, size_hint_y=None, height=dp(46),
                         padding=[dp(12), dp(12)], background_normal="",
                         background_active="", background_color=PANEL2,
                         foreground_color=WHITE, hint_text_color=MUTED,
                         cursor_color=GREEN, font_size="15sp")

    def show_page(self, page):
        self.current_page = page
        self.body.clear_widgets()
        scroll = ScrollView(do_scroll_x=False, bar_width=dp(4))
        content = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(12),
                            size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))
        scroll.add_widget(content)
        self.body.add_widget(scroll)

        if page == "home":
            self.page_home(content)
        elif page == "sales":
            self.page_sales(content)
        elif page == "expenses":
            self.page_expenses(content)
        elif page == "reports":
            self.page_reports(content)
        elif page == "stock":
            self.page_stock(content)

    def section_title(self, parent, title, subtitle=None):
        parent.add_widget(self.make_label(f"[b]{title}[/b]", 22, WHITE, True, height=34))
        if subtitle:
            parent.add_widget(self.make_label(subtitle, 12, MUTED, height=24))

    def stat_card(self, parent, title, value, accent):
        card = Card(bg=PANEL, size_hint_y=None, height=dp(100))
        card.add_widget(self.make_label(title, 12, MUTED, height=24))
        card.add_widget(self.make_label(f"[b]{value}[/b]", 19, accent, True, height=34))
        parent.add_widget(card)

    def get_summary(self, start, end):
        s = self.query("""SELECT COALESCE(SUM(quantity*unit_price),0) revenue,
                          COALESCE(SUM(quantity*unit_cost),0) cogs, COUNT(*) entries
                          FROM sales WHERE sale_date BETWEEN ? AND ?""", (start, end), one=True)
        e = self.query("""SELECT COALESCE(SUM(amount),0) total, COUNT(*) entries
                          FROM expenses WHERE expense_date BETWEEN ? AND ?""", (start, end), one=True)
        revenue, cogs, expenses = float(s["revenue"]), float(s["cogs"]), float(e["total"])
        return {"revenue": revenue, "cogs": cogs, "expenses": expenses,
                "gross": revenue-cogs, "net": revenue-cogs-expenses,
                "sales_count": s["entries"], "expense_count": e["entries"]}

    def page_home(self, parent):
        self.section_title(parent, "Today's Overview", datetime.now().strftime("%A, %d %b %Y"))
        sm = self.get_summary(today(), today())
        grid = GridLayout(cols=2, spacing=dp(9), size_hint_y=None)
        grid.bind(minimum_height=grid.setter("height"))
        data = [("Total Sales", sm["revenue"], GREEN), ("Cost of Goods Sold", sm["cogs"], BLUE),
                ("Total Expenses", sm["expenses"], ORANGE), ("Gross Profit", sm["gross"], PURPLE),
                ("Net Profit", sm["net"], CYAN)]
        for title, value, color in data:
            self.stat_card(grid, title, ksh(value), color)
        parent.add_widget(grid)

        self.section_title(parent, "Quick Actions")
        actions = GridLayout(cols=2, spacing=dp(8), size_hint_y=None, row_default_height=dp(48), row_force_default=True)
        actions.bind(minimum_height=actions.setter("height"))
        actions.add_widget(self.make_button("+ Record Sale", lambda *_: self.sale_popup()))
        actions.add_widget(self.make_button("+ Record Expense", lambda *_: self.expense_popup(), bg=ORANGE))
        actions.add_widget(self.make_button("+ Add Product", lambda *_: self.product_popup(), bg=BLUE))
        actions.add_widget(self.make_button("View Reports", lambda *_: self.show_page("reports"), bg=PURPLE))
        parent.add_widget(actions)

        self.section_title(parent, "Recent Transactions")
        sales = self.query("SELECT sale_date, product_name description, quantity*unit_price amount, 'Sale' kind FROM sales ORDER BY id DESC LIMIT 5")
        expenses = self.query("SELECT expense_date, description, amount, 'Expense' kind FROM expenses ORDER BY id DESC LIMIT 5")
        rows = sorted(list(sales)+list(expenses), key=lambda r: (r["sale_date"], r["kind"]), reverse=True)[:8]
        if not rows:
            parent.add_widget(self.make_label("No records yet. Add a sale or expense to get started.", 13, MUTED, height=38))
        for row in rows:
            card = Card(bg=PANEL, size_hint_y=None, height=dp(56), orientation="horizontal")
            left = BoxLayout(orientation="vertical")
            left.add_widget(self.make_label(row["description"], 13, WHITE, height=25))
            left.add_widget(self.make_label(f'{row["sale_date"]} · {row["kind"]}', 10, MUTED, height=20))
            card.add_widget(left)
            card.add_widget(self.make_label(ksh(row["amount"]), 13, GREEN if row["kind"]=="Sale" else ORANGE, height=40, halign="right"))
            parent.add_widget(card)

    def page_sales(self, parent):
        self.section_title(parent, "Sales", "Record a sale and automatically reduce stock when a matching product exists.")
        parent.add_widget(self.make_button("+ Record Sale", lambda *_: self.sale_popup()))
        rows = self.query("SELECT sale_date, product_name, quantity, unit_price, payment_method FROM sales ORDER BY id DESC LIMIT 100")
        if not rows:
            parent.add_widget(self.make_label("No sales recorded yet.", 14, MUTED, height=40))
        for r in rows:
            c = Card(bg=PANEL, size_hint_y=None, height=dp(68))
            c.add_widget(self.make_label(f'[b]{r["product_name"]} × {r["quantity"]}[/b]  ·  {ksh(r["quantity"]*r["unit_price"])}', 14, WHITE, True, height=28))
            c.add_widget(self.make_label(f'{r["sale_date"]}  ·  {r["payment_method"]}', 11, MUTED, height=22))
            parent.add_widget(c)

    def page_expenses(self, parent):
        self.section_title(parent, "Expenses", "Track rent, transport, utilities and other costs.")
        parent.add_widget(self.make_button("+ Record Expense", lambda *_: self.expense_popup(), bg=ORANGE))
        rows = self.query("SELECT expense_date, category, description, amount, payment_method FROM expenses ORDER BY id DESC LIMIT 100")
        if not rows:
            parent.add_widget(self.make_label("No expenses recorded yet.", 14, MUTED, height=40))
        for r in rows:
            c = Card(bg=PANEL, size_hint_y=None, height=dp(70))
            c.add_widget(self.make_label(f'[b]{r["category"]} · {ksh(r["amount"])}[/b]', 14, ORANGE, True, height=27))
            c.add_widget(self.make_label(f'{r["description"]} · {r["expense_date"]} · {r["payment_method"]}', 11, MUTED, height=25))
            parent.add_widget(c)

    def page_stock(self, parent):
        self.section_title(parent, "Stock Management", "Products, selling prices, cost prices and available quantity.")
        parent.add_widget(self.make_button("+ Add Product", lambda *_: self.product_popup(), bg=BLUE))
        rows = self.query("SELECT name, cost, price, stock FROM products ORDER BY name COLLATE NOCASE")
        if not rows:
            parent.add_widget(self.make_label("No products yet. Add your first product.", 14, MUTED, height=40))
        for r in rows:
            c = Card(bg=PANEL, size_hint_y=None, height=dp(78))
            stock_color = ORANGE if r["stock"] < 6 else GREEN
            c.add_widget(self.make_label(f'[b]{r["name"]}[/b]', 15, WHITE, True, height=27))
            c.add_widget(self.make_label(f'Cost {ksh(r["cost"])}  ·  Price {ksh(r["price"])}  ·  Stock: [color={ "FF9B18" if r["stock"] < 6 else "00D96B"}]{r["stock"]}[/color]', 11, MUTED, True, height=25))
            parent.add_widget(c)

    def page_reports(self, parent):
        self.section_title(parent, "Reports", "Daily and monthly totals calculated from saved transactions.")
        parent.add_widget(self.make_button("Generate Daily Report", lambda *_: self.report_popup("daily"), bg=PURPLE))
        parent.add_widget(self.make_button("Generate Monthly Report", lambda *_: self.report_popup("monthly"), bg=BLUE))
        sm = self.get_summary(today(), today())
        card = Card(bg=PANEL, size_hint_y=None, height=dp(218))
        card.add_widget(self.make_label("[b]Today's Snapshot[/b]", 17, WHITE, True, height=30))
        for label, key, color in [("Sales Revenue","revenue",GREEN),("Cost of Goods Sold","cogs",BLUE),
                                  ("Expenses","expenses",ORANGE),("Gross Profit","gross",PURPLE),("Net Profit","net",CYAN)]:
            row = BoxLayout(size_hint_y=None, height=dp(30))
            row.add_widget(self.make_label(label, 12, MUTED, height=28))
            row.add_widget(self.make_label(ksh(sm[key]), 12, color, height=28, halign="right"))
            card.add_widget(row)
        parent.add_widget(card)
        parent.add_widget(self.make_label("Reports are stored locally and can be exported in a later release.", 11, MUTED, height=35))

    def popup_base(self, title, height=dp(500)):
        box = BoxLayout(orientation="vertical", spacing=dp(9), padding=dp(14))
        popup = Popup(title=title, content=box, size_hint=(0.94, None), height=height,
                      background_color=PANEL, title_color=WHITE, separator_color=GREEN)
        return popup, box

    def sale_popup(self):
        popup, box = self.popup_base("Record Sale", dp(560))
        product_names = [r["name"] for r in self.query("SELECT name FROM products ORDER BY name")]
        product = Spinner(text=(product_names[0] if product_names else "Enter product name"),
                          values=product_names, size_hint_y=None, height=dp(46),
                          background_normal="", background_color=PANEL2, color=WHITE)
        name_input = self.text_input("Product / item name")
        date_input = self.text_input("Sale date YYYY-MM-DD", today())
        qty = self.text_input("Quantity", "1", input_filter="int")
        price = self.text_input("Selling price per item (KSh)", input_filter="float")
        cost = self.text_input("Cost per item (KSh)", "0", input_filter="float")
        pay = Spinner(text="Cash", values=["Cash","M-Pesa","Card","Credit"],
                      size_hint_y=None, height=dp(46), background_normal="", background_color=PANEL2, color=WHITE)
        for widget in [product, name_input, date_input, qty, price, cost, pay]:
            box.add_widget(widget)
        def save(*_):
            name = name_input.text.strip() or (product.text if product.text != "Enter product name" else "")
            try:
                d = valid_date(date_input.text)
                q = int(qty.text)
                p = float(price.text)
                c = float(cost.text or "0")
                if not name or q <= 0 or p < 0 or c < 0:
                    raise ValueError
                existing = self.query("SELECT id, stock, price, cost FROM products WHERE name=? COLLATE NOCASE", (name,), one=True)
                with sqlite3.connect(self.db_path) as con:
                    con.execute("INSERT INTO sales(sale_date,product_name,quantity,unit_price,unit_cost,payment_method) VALUES(?,?,?,?,?,?)",
                                (d,name,q,p,c,pay.text))
                    if existing:
                        con.execute("UPDATE products SET stock=MAX(0, stock-?), updated_at=CURRENT_TIMESTAMP WHERE id=?", (q,existing["id"]))
                popup.dismiss()
                self.show_page(self.current_page)
                self.notice("Sale saved successfully.")
            except (ValueError, sqlite3.Error):
                self.notice("Check the product, date, quantity, price and cost.")
        box.add_widget(self.make_button("Save Sale", save))
        box.add_widget(self.make_button("Cancel", lambda *_: popup.dismiss(), bg=PANEL2))
        popup.open()

    def expense_popup(self):
        popup, box = self.popup_base("Record Expense", dp(500))
        date_input = self.text_input("Expense date YYYY-MM-DD", today())
        category = Spinner(text="Transport", values=["Rent","Transport","Utilities","Wages","Stock Purchase","Repairs","Other"],
                           size_hint_y=None, height=dp(46), background_normal="", background_color=PANEL2, color=WHITE)
        desc = self.text_input("Description (e.g. delivery)")
        amount = self.text_input("Amount (KSh)", input_filter="float")
        pay = Spinner(text="Cash", values=["Cash","M-Pesa","Card"], size_hint_y=None,
                      height=dp(46), background_normal="", background_color=PANEL2, color=WHITE)
        for w in [date_input, category, desc, amount, pay]:
            box.add_widget(w)
        def save(*_):
            try:
                d = valid_date(date_input.text)
                a = float(amount.text)
                if not desc.text.strip() or a <= 0:
                    raise ValueError
                self.execute("INSERT INTO expenses(expense_date,category,description,amount,payment_method) VALUES(?,?,?,?,?)",
                             (d,category.text,desc.text.strip(),a,pay.text))
                popup.dismiss()
                self.show_page(self.current_page)
                self.notice("Expense saved successfully.")
            except (ValueError, sqlite3.Error):
                self.notice("Enter a valid date, description and positive amount.")
        box.add_widget(self.make_button("Save Expense", save, bg=ORANGE))
        box.add_widget(self.make_button("Cancel", lambda *_: popup.dismiss(), bg=PANEL2))
        popup.open()

    def product_popup(self):
        popup, box = self.popup_base("Add / Update Product", dp(500))
        name = self.text_input("Product name")
        cost = self.text_input("Cost price per item (KSh)", input_filter="float")
        price = self.text_input("Selling price per item (KSh)", input_filter="float")
        stock = self.text_input("Opening stock (whole number)", "0", input_filter="int")
        for w in [name,cost,price,stock]:
            box.add_widget(w)
        def save(*_):
            try:
                n=name.text.strip(); c=float(cost.text); p=float(price.text); s=int(stock.text)
                if not n or c < 0 or p < 0 or s < 0:
                    raise ValueError
                with sqlite3.connect(self.db_path) as con:
                    con.execute("""INSERT INTO products(name,cost,price,stock) VALUES(?,?,?,?)
                    ON CONFLICT(name) DO UPDATE SET cost=excluded.cost, price=excluded.price,
                    stock=products.stock+excluded.stock, updated_at=CURRENT_TIMESTAMP""",(n,c,p,s))
                popup.dismiss()
                self.show_page("stock")
                self.notice("Product saved. Existing stock was increased if product already existed.")
            except (ValueError, sqlite3.Error):
                self.notice("Enter a name, valid prices and a non-negative whole stock quantity.")
        box.add_widget(self.make_button("Save Product", save, bg=BLUE))
        box.add_widget(self.make_button("Cancel", lambda *_: popup.dismiss(), bg=PANEL2))
        popup.open()

    def report_popup(self, mode):
        title = "Daily Report" if mode == "daily" else "Monthly Report"
        popup, box = self.popup_base(title, dp(480))
        default = today() if mode == "daily" else date.today().strftime("%Y-%m")
        period = self.text_input("Date YYYY-MM-DD" if mode == "daily" else "Month YYYY-MM", default)
        box.add_widget(period)
        result = BoxLayout(orientation="vertical", spacing=dp(5))
        box.add_widget(result)
        def generate(*_):
            result.clear_widgets()
            try:
                if mode == "daily":
                    d = valid_date(period.text)
                    start = end = d
                else:
                    d = datetime.strptime(period.text.strip(), "%Y-%m").date()
                    start = d.replace(day=1).isoformat()
                    if d.month == 12:
                        end = date(d.year+1,1,1) - timedelta(days=1)
                    else:
                        end = date(d.year,d.month+1,1) - timedelta(days=1)
                    end = end.isoformat()
                sm = self.get_summary(start,end)
                result.add_widget(self.make_label(f"{start}  to  {end}", 11, MUTED, height=23))
                for label,key,color in [("Sales Revenue","revenue",GREEN),("Cost of Goods Sold","cogs",BLUE),
                                        ("Gross Profit","gross",PURPLE),("Expenses","expenses",ORANGE),("NET PROFIT","net",CYAN)]:
                    result.add_widget(self.make_label(f"{label}:  {ksh(sm[key])}", 14, color, height=29))
                result.add_widget(self.make_label(f'Sale entries: {sm["sales_count"]}   ·   Expense entries: {sm["expense_count"]}', 11, MUTED, height=26))
            except ValueError:
                result.add_widget(self.make_label("Enter a valid date/month.", 13, RED, height=28))
        box.add_widget(self.make_button("Calculate Report", generate, bg=PURPLE))
        box.add_widget(self.make_button("Close", lambda *_: popup.dismiss(), bg=PANEL2))
        generate()
        popup.open()

    def notice(self, message):
        box = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(12))
        box.add_widget(Label(text=message, color=WHITE))
        popup = Popup(title="DukaBI", content=box, size_hint=(0.85, None), height=dp(180),
                      background_color=PANEL, title_color=WHITE, separator_color=GREEN)
        box.add_widget(self.make_button("OK", lambda *_: popup.dismiss()))
        popup.open()

    def toggle_theme(self, *_):
        # The initial release keeps the selected dark-navy design.
        self.notice("DukaBI is using its dark navy theme in this first release.")

if __name__ == "__main__":
    DukaBIApp().run()
