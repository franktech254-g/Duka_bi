# DukaBI Android

DukaBI is a starter Android shop-management app built with Python, Flet and SQLite. It includes a dark navy dashboard, sales entry, expenses, product/stock management and daily/monthly summaries.

## Build an APK with GitHub Actions (phone-friendly)

1. Create a GitHub repository, for example `DukaBI-Android`.
2. Upload all files and folders from this project, including the hidden `.github/workflows/android.yml`.
3. Ensure the workflow path is exactly `.github/workflows/android.yml`.
4. Open the repository's **Actions** tab.
5. Choose **Build DukaBI Android APK** and tap **Run workflow**. A push to `main` also starts a build.
6. When the run succeeds, open it and download the `DukaBI-debug-apk` artifact ZIP.
7. Extract the ZIP and install the `.apk` on your Android phone. Android may ask you to allow installs from your browser or file manager.

## Important

- This is a debug APK for testing, not a signed release for the Play Store.
- SQLite data is stored locally on the device. Uninstalling the app may remove its data; keep backups before using it for real shop records.
- This starter does not include M-Pesa, subscriptions, cloud backup, multi-user sync, tax handling or receipt printing.
- Test all totals and stock movements with sample records before using it for business.
- If the build fails, open the failed GitHub Actions run and share the first meaningful error from the logs for troubleshooting.

## Run locally

Install Python and Flet, then run:

```bash
pip install -r requirements.txt
python main.py
```
