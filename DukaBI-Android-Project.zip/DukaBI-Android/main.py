import flet as ft
import sqlite3
from datetime import date, datetime
from pathlib import Path

APP_NAME = "DukaBI"
DB_PATH = Path(__file__).resolve().parent / "dukabi.db"
NAVY = "#0B1220"
PANEL = "#121C2E"
ACCENT = "#38BDF8"
GREEN = "#34D399"
RED = "#FB7185"
TEXT = "#F1F5F9"
MUTED = "#94A3B8"


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            cost REAL NOT NULL DEFAULT 0,
            price REAL NOT NULL DEFAULT 0,
            stock INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS sales(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            product_name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            unit_cost REAL NOT NULL DEFAULT 0,
            total REAL NOT NULL,
            profit REAL NOT NULL DEFAULT 0,
            sold_at TEXT NOT NULL,
            FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
        );
        CREATE TABLE IF NOT EXISTS expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            description TEXT NOT NULL,
            amount REAL NOT NULL,
            spent_at TEXT NOT NULL
        );
        """)


def ksh(value):
    return "KSh {:,.2f}".format(float(value or 0))


def snack(page, message, error=False):
    page.snack_bar = ft.SnackBar(
        content=ft.Text(message, color=TEXT),
        bgcolor=RED if error else "#1E293B",
    )
    page.snack_bar.open = True
    page.update()


def main(page: ft.Page):
    init_db()
    page.title = "DukaBI — Shop Manager"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = NAVY
    page.padding = 0
    page.spacing = 0
    page.window_min_width = 320
    page.theme = ft.Theme(color_scheme_seed=ACCENT, use_material3=True)

    body = ft.Container(expand=True, padding=16)
    selected_tab = {"index": 0}

    def panel(content, padding=14):
        return ft.Container(content=content, bgcolor=PANEL, border_radius=16, padding=padding)

    def label(text, size=14, color=MUTED, weight=None):
        return ft.Text(text, size=size, color=color, weight=weight)

    def field(hint, **kwargs):
        return ft.TextField(
            label=hint, border_radius=10, text_size=16,
            border_color="#334155", focused_border_color=ACCENT,
            **kwargs
        )

    def summary_values():
        today = date.today().isoformat()
        month = date.today().strftime("%Y-%m")
        with db() as con:
            sales_today = con.execute("SELECT COALESCE(SUM(total),0) FROM sales WHERE substr(sold_at,1,10)=?", (today,)).fetchone()[0]
            profit_today = con.execute("SELECT COALESCE(SUM(profit),0) FROM sales WHERE substr(sold_at,1,10)=?", (today,)).fetchone()[0]
            expenses_today = con.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE substr(spent_at,1,10)=?", (today,)).fetchone()[0]
            stock_count = con.execute("SELECT COALESCE(SUM(stock),0) FROM products").fetchone()[0]
            month_sales = con.execute("SELECT COALESCE(SUM(total),0) FROM sales WHERE substr(sold_at,1,7)=?", (month,)).fetchone()[0]
            month_expenses = con.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE substr(spent_at,1,7)=?", (month,)).fetchone()[0]
            return sales_today, profit_today, expenses_today, stock_count, month_sales, month_expenses

    def stat_card(title, value, icon, color=TEXT):
        return ft.Container(
            expand=True, bgcolor=PANEL, border_radius=14, padding=14,
            content=ft.Column([
                ft.Row([ft.Icon(icon, color=ACCENT, size=20), label(title, 12)], spacing=8),
                ft.Text(value, size=20, weight=ft.FontWeight.BOLD, color=color),
            ], spacing=10)
        )

    def show_dashboard():
        s, p, e, stock, ms, me = summary_values()
        content = ft.Column([
            ft.Row([
                ft.Column([
                    ft.Text("DukaBI", size=27, weight=ft.FontWeight.BOLD, color=TEXT),
                    label("SHOP MANAGEMENT", 11, ACCENT, ft.FontWeight.BOLD),
                ], spacing=2, expand=True),
                ft.Container(
                    content=ft.Icon(ft.Icons.SHOPPING_CART_CHECKOUT, color=ACCENT, size=26),
                    bgcolor="#1E293B", border_radius=12, padding=12
                )
            ]),
            label(datetime.now().strftime("%A, %d %B %Y"), 13),
            ft.Divider(color="#263449"),
            ft.Text("Today's overview", size=18, weight=ft.FontWeight.BOLD),
            ft.Row([stat_card("Sales today", ksh(s), ft.Icons.POINT_OF_SALE, GREEN),
                    stat_card("Gross profit", ksh(p), ft.Icons.TRENDING_UP, GREEN)], spacing=10),
            ft.Row([stat_card("Expenses today", ksh(e), ft.Icons.RECEIPT_LONG, RED),
                    stat_card("Items in stock", str(stock), ft.Icons.INVENTORY_2)], spacing=10),
            ft.Text("This month", size=18, weight=ft.FontWeight.BOLD),
            panel(ft.Column([
                ft.Row([label("Sales", 14), ft.Text(ksh(ms), size=16, weight=ft.FontWeight.BOLD, color=GREEN)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([label("Expenses", 14), ft.Text(ksh(me), size=16, weight=ft.FontWeight.BOLD, color=RED)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Divider(color="#334155"),
                ft.Row([label("Profit after expenses", 14, TEXT), ft.Text(ksh(p + 0 if False else (month_profit() - me)), size=16, weight=ft.FontWeight.BOLD, color=ACCENT)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ], spacing=10)),
            ft.Text("Quick actions", size=18, weight=ft.FontWeight.BOLD),
            ft.Row([
                ft.FilledButton("Record sale", icon=ft.Icons.ADD_SHOPPING_CART, on_click=lambda e: navigate(1), expand=True),
                ft.OutlinedButton("Add expense", icon=ft.Icons.RECEIPT, on_click=lambda e: navigate(2), expand=True),
            ], spacing=10),
            label("Your data is stored locally on this device.", 12),
        ], spacing=14, scroll=ft.ScrollMode.AUTO)
        body.content = content
        page.update()

    def month_profit():
        month = date.today().strftime("%Y-%m")
        with db() as con:
            return con.execute("SELECT COALESCE(SUM(profit),0) FROM sales WHERE substr(sold_at,1,7)=?", (month,)).fetchone()[0]

    def navigate(index):
        selected_tab["index"] = index
        if index == 0:
            show_dashboard()
        elif index == 1:
            show_sales()
        elif index == 2:
            show_expenses()
        elif index == 3:
            show_stock()
        else:
            show_reports()
        nav.selected_index = index
        page.update()

    def show_sales():
        product_dd = ft.Dropdown(label="Product", border_radius=10, options=[], text_size=16)
        qty = field("Quantity", value="1", keyboard_type=ft.KeyboardType.NUMBER)
        with db() as con:
            rows = con.execute("SELECT id,name,price,stock,cost FROM products ORDER BY name").fetchall()
        product_dd.options = [ft.dropdown.Option(str(r["id"]), f'{r["name"]} (stock: {r["stock"]})') for r in rows]
        info = ft.Text("Select a product. Add products in Stock first.", color=MUTED, size=13)

        def update_info(e=None):
            item = next((r for r in rows if str(r["id"]) == product_dd.value), None)
            if item:
                info.value = f'Price: {ksh(item["price"])} • Available: {item["stock"]}'
                page.update()

        product_dd.on_change = update_info

        def save_sale(e):
            if not product_dd.value:
                snack(page, "Please select a product.", True); return
            try:
                quantity = int(qty.value)
                if quantity < 1: raise ValueError()
            except Exception:
                snack(page, "Enter a valid quantity.", True); return
            item = next((r for r in rows if str(r["id"]) == product_dd.value), None)
            if not item:
                snack(page, "Product not found. Refresh this page.", True); return
            if quantity > item["stock"]:
                snack(page, "Not enough stock available.", True); return
            total = quantity * item["price"]
            profit = quantity * (item["price"] - item["cost"])
            with db() as con:
                con.execute("UPDATE products SET stock=stock-? WHERE id=?", (quantity, item["id"]))
                con.execute("INSERT INTO sales(product_id,product_name,quantity,unit_price,unit_cost,total,profit,sold_at) VALUES(?,?,?,?,?,?,?,?)",
                    (item["id"], item["name"], quantity, item["price"], item["cost"], total, profit, datetime.now().isoformat(timespec="seconds")))
            snack(page, f"Sale saved: {ksh(total)}")
            show_sales()

        with db() as con:
            recent = con.execute("SELECT product_name,quantity,total,sold_at FROM sales ORDER BY id DESC LIMIT 10").fetchall()
        recent_controls = [ft.ListTile(
            leading=ft.Icon(ft.Icons.CHECK_CIRCLE, color=GREEN),
            title=ft.Text(f'{r["product_name"]} × {r["quantity"]}'),
            subtitle=label(r["sold_at"].replace("T", " ")[:16], 12),
            trailing=ft.Text(ksh(r["total"]), weight=ft.FontWeight.BOLD)
        ) for r in recent]
        body.content = ft.Column([
            ft.Text("Record a sale", size=24, weight=ft.FontWeight.BOLD),
            panel(ft.Column([product_dd, qty, info, ft.FilledButton("Save sale", icon=ft.Icons.SAVE, on_click=save_sale, width=float("inf"))], spacing=12)),
            ft.Text("Recent sales", size=18, weight=ft.FontWeight.BOLD),
            panel(ft.Column(recent_controls or [label("No sales recorded yet.")], spacing=4)),
        ], spacing=14, scroll=ft.ScrollMode.AUTO)
        page.update()

    def show_expenses():
        description = field("Expense description", hint_text="e.g. Transport, rent")
        amount = field("Amount (KSh)", keyboard_type=ft.KeyboardType.NUMBER)

        def save_expense(e):
            desc = (description.value or "").strip()
            try:
                value = float(amount.value)
                if not desc or value <= 0: raise ValueError()
            except Exception:
                snack(page, "Enter a description and a valid amount.", True); return
            with db() as con:
                con.execute("INSERT INTO expenses(description,amount,spent_at) VALUES(?,?,?)",
                            (desc, value, datetime.now().isoformat(timespec="seconds")))
            snack(page, "Expense saved.")
            show_expenses()

        with db() as con:
            rows = con.execute("SELECT description,amount,spent_at FROM expenses ORDER BY id DESC LIMIT 15").fetchall()
        items = [ft.ListTile(
            leading=ft.Icon(ft.Icons.RECEIPT_LONG, color=RED),
            title=ft.Text(r["description"]),
            subtitle=label(r["spent_at"].replace("T", " ")[:16], 12),
            trailing=ft.Text(ksh(r["amount"]), color=RED, weight=ft.FontWeight.BOLD)
        ) for r in rows]
        body.content = ft.Column([
            ft.Text("Expenses", size=24, weight=ft.FontWeight.BOLD),
            panel(ft.Column([description, amount, ft.FilledButton("Save expense", icon=ft.Icons.SAVE, on_click=save_expense, width=float("inf"))], spacing=12)),
            ft.Text("Recent expenses", size=18, weight=ft.FontWeight.BOLD),
            panel(ft.Column(items or [label("No expenses recorded yet.")], spacing=4)),
        ], spacing=14, scroll=ft.ScrollMode.AUTO)
        page.update()

    def show_stock():
        name = field("Product name")
        cost = field("Cost price (KSh)", keyboard_type=ft.KeyboardType.NUMBER)
        price = field("Selling price (KSh)", keyboard_type=ft.KeyboardType.NUMBER)
        quantity = field("Opening / added stock quantity", value="0", keyboard_type=ft.KeyboardType.NUMBER)

        def save_product(e):
            product_name = (name.value or "").strip()
            try:
                c, p, q = float(cost.value), float(price.value), int(quantity.value)
                if not product_name or c < 0 or p < 0 or q < 0: raise ValueError()
            except Exception:
                snack(page, "Check the product name, prices and quantity.", True); return
            try:
                with db() as con:
                    existing = con.execute("SELECT id FROM products WHERE name=?", (product_name,)).fetchone()
                    if existing:
                        con.execute("UPDATE products SET cost=?,price=?,stock=stock+? WHERE id=?", (c,p,q,existing["id"]))
                    else:
                        con.execute("INSERT INTO products(name,cost,price,stock) VALUES(?,?,?,?)", (product_name,c,p,q))
            except sqlite3.Error:
                snack(page, "Could not save product.", True); return
            snack(page, "Product saved. Existing products have had stock added.")
            show_stock()

        def restock(product_id, product_name):
            add = ft.TextField(label=f"Units to add to {product_name}", keyboard_type=ft.KeyboardType.NUMBER)
            def apply(e):
                try:
                    n = int(add.value)
                    if n < 1: raise ValueError()
                except Exception:
                    snack(page, "Enter a positive whole number.", True); return
                with db() as con:
                    con.execute("UPDATE products SET stock=stock+? WHERE id=?", (n, product_id))
                dlg.open = False
                page.update()
                show_stock()
                snack(page, "Stock updated.")
            dlg = ft.AlertDialog(title=ft.Text("Restock product"), content=add, actions=[ft.TextButton("Cancel", on_click=lambda e: close_dlg()), ft.FilledButton("Add stock", on_click=apply)])
            def close_dlg():
                dlg.open = False; page.update()
            page.overlay.append(dlg); dlg.open = True; page.update()

        with db() as con:
            rows = con.execute("SELECT * FROM products ORDER BY name").fetchall()
        products = [ft.ListTile(
            leading=ft.Icon(ft.Icons.INVENTORY_2, color=ACCENT),
            title=ft.Text(r["name"]),
            subtitle=label(f'Cost {ksh(r["cost"])} • Price {ksh(r["price"])} • Stock {r["stock"]}', 12),
            trailing=ft.IconButton(icon=ft.Icons.ADD_BOX, tooltip="Add stock", on_click=lambda e, rid=r["id"], rn=r["name"]: restock(rid, rn))
        ) for r in rows]
        body.content = ft.Column([
            ft.Text("Products & stock", size=24, weight=ft.FontWeight.BOLD),
            panel(ft.Column([name, cost, price, quantity, ft.FilledButton("Save product", icon=ft.Icons.ADD, on_click=save_product, width=float("inf"))], spacing=12)),
            ft.Text(f"Product list ({len(rows)})", size=18, weight=ft.FontWeight.BOLD),
            panel(ft.Column(products or [label("Add your first product above.")], spacing=4)),
        ], spacing=14, scroll=ft.ScrollMode.AUTO)
        page.update()

    def show_reports():
        today = date.today().isoformat()
        month = date.today().strftime("%Y-%m")
        with db() as con:
            today_sales = con.execute("SELECT COALESCE(SUM(total),0) FROM sales WHERE substr(sold_at,1,10)=?", (today,)).fetchone()[0]
            today_profit = con.execute("SELECT COALESCE(SUM(profit),0) FROM sales WHERE substr(sold_at,1,10)=?", (today,)).fetchone()[0]
            today_exp = con.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE substr(spent_at,1,10)=?", (today,)).fetchone()[0]
            month_sales = con.execute("SELECT COALESCE(SUM(total),0) FROM sales WHERE substr(sold_at,1,7)=?", (month,)).fetchone()[0]
            month_profit_val = con.execute("SELECT COALESCE(SUM(profit),0) FROM sales WHERE substr(sold_at,1,7)=?", (month,)).fetchone()[0]
            month_exp = con.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE substr(spent_at,1,7)=?", (month,)).fetchone()[0]
        body.content = ft.Column([
            ft.Text("Reports", size=24, weight=ft.FontWeight.BOLD),
            label("Daily summary • " + today, 13, ACCENT, ft.FontWeight.BOLD),
            panel(ft.Column([
                ft.Row([label("Sales", 14), ft.Text(ksh(today_sales), color=GREEN, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([label("Gross profit", 14), ft.Text(ksh(today_profit), color=GREEN, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([label("Expenses", 14), ft.Text(ksh(today_exp), color=RED, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([label("Profit after expenses", 14), ft.Text(ksh(today_profit-today_exp), color=ACCENT, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ], spacing=12)),
            label("Monthly summary • " + month, 13, ACCENT, ft.FontWeight.BOLD),
            panel(ft.Column([
                ft.Row([label("Sales", 14), ft.Text(ksh(month_sales), color=GREEN, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([label("Gross profit", 14), ft.Text(ksh(month_profit_val), color=GREEN, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([label("Expenses", 14), ft.Text(ksh(month_exp), color=RED, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([label("Profit after expenses", 14), ft.Text(ksh(month_profit_val-month_exp), color=ACCENT, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ], spacing=12)),
            label("Profit estimates use recorded product cost and sales; taxes, credit sales and other costs are not included.", 12),
        ], spacing=14, scroll=ft.ScrollMode.AUTO)
        page.update()

    nav = ft.NavigationBar(
        selected_index=0,
        bgcolor="#0F172A",
        indicator_color="#1E3A5F",
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.DASHBOARD_OUTLINED, selected_icon=ft.Icons.DASHBOARD, label="Home"),
            ft.NavigationBarDestination(icon=ft.Icons.POINT_OF_SALE, label="Sales"),
            ft.NavigationBarDestination(icon=ft.Icons.RECEIPT_LONG, label="Expenses"),
            ft.NavigationBarDestination(icon=ft.Icons.INVENTORY_2_OUTLINED, label="Stock"),
            ft.NavigationBarDestination(icon=ft.Icons.ANALYTICS_OUTLINED, label="Reports"),
        ],
        on_change=lambda e: navigate(e.control.selected_index),
    )
    page.add(ft.SafeArea(content=body, expand=True), nav)
    show_dashboard()


if __name__ == "__main__":
    ft.run(main)
